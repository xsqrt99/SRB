#!/bin/sh

# change wallet and password

./SRBMiner-MULTI --algorithm randomepic --pool epic.icemining.ca:4000 --wallet your-username --password your-password
