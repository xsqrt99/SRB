#!/bin/sh

./SRBMiner-MULTI --config-file ./Config/config-yespowerlitb.txt --pools-file ./Pools/pools-LITB.txt
